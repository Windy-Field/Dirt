# 泥梦新韵

齐鲁封泥文物传播与数字化保护网站。项目已经整理为可直接部署到阿里云函数计算 FC 的 Node.js Web 服务。

## 功能

- 调研文物与文物价值展示
- 齐鲁封泥文化地图
- 支教开源课程
- 数字拓印和图像增强
- 封泥文创展厅
- “丁见泥”AI助手
- 多张图片上传、预览和删除
- 千问多模态图片分析
- 百炼智能体应用与知识库问答

## AI调用路线

纯文字问题：

```text
浏览器 → POST /api/ai/chat → 百炼智能体应用 Completion API
```

包含图片的问题：

```text
浏览器 → POST /api/ai/chat → DashScope OpenAI兼容接口 → qwen-vl-plus
```

默认百炼应用 ID：

```text
c786fc9824414081980b6aa3258bb787
```

## 本地开发

需要 Node.js 18 或更高版本：

```powershell
$env:DASHSCOPE_API_KEY="你的百炼API Key"
npm start
```

打开：

```text
http://127.0.0.1:3000
```

## 部署

参见 [DEPLOY-FC.md](./DEPLOY-FC.md)。部署到 FC 后，用户直接打开 FC 的公网地址即可使用，不需要运行 BAT，也不需要正式域名。

## 环境变量

```text
DASHSCOPE_API_KEY       必填，只在服务端配置
DASHSCOPE_APP_ID        可选，已有默认应用ID
QWEN_VL_MODEL           可选，默认 qwen-vl-plus
PORT                    FC 或本地监听端口
```

不要把 `DASHSCOPE_API_KEY` 写入任何 HTML、JavaScript 或提交到代码仓库。
