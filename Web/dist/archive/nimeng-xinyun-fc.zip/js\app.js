(function () {
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];
  const modeNames = { original: "原貌模式", contrast: "高对比增强", rubbing: "数字拓印", labels: "印文释读" };
  let courses = [];
  let selectedImages = [];
  let aiSessionId = window.sessionStorage.getItem("nimeng-ai-session") || "";
  const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));

  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("show");
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 2600);
  }

  function createRelicVisual(item) {
    const chars = [...item.inscription].slice(0, 4);
    while (chars.length < 4) chars.push("印");
    return `<div class="relic-visual ${item.tone}" aria-label="${item.name}数字复原图"><div class="relic-disc"><div class="mini-inscription">${chars.map((char) => `<span>${char}</span>`).join("")}</div></div><span class="relic-code">${item.id}</span></div>`;
  }

  function renderRelics(items) {
    $("#collectionGrid").innerHTML = items.length ? items.map((item) => `<article class="relic-card">${createRelicVisual(item)}<div class="relic-info"><div><span>${item.period}</span><span>${item.value}</span></div><h3>${item.name}</h3><p>${item.summary}</p><button type="button" data-relic-id="${item.id}">查看调研档案 <span>→</span></button></div></article>`).join("") : '<div class="empty-state"><strong>暂未找到相关封泥</strong><p>换一个名称、年代或地点试试。</p></div>';
  }

  function updateSitePanel(site, index = 0) {
    $("#siteNumber").textContent = String(index + 1).padStart(2, "0");
    $("#siteCity").textContent = site.city; $("#siteName").textContent = site.name; $("#siteDescription").textContent = site.description;
    $("#sitePeriod").textContent = site.period; $("#siteCount").textContent = `${site.count} 件`;
  }

  function renderSites(sites) {
    const root = $("#mapMarkers");
    root.innerHTML = sites.map((site, index) => `<button class="map-marker${index === 0 ? " active" : ""}" type="button" style="left:${site.x}%;top:${site.y}%" data-site-id="${site.id}" aria-label="查看${site.city}"><i></i><span>${site.city.split(" · ")[0]}</span></button>`).join("");
    if (sites.length) updateSitePanel(sites[0]);
    $$(".map-marker", root).forEach((marker) => marker.addEventListener("click", () => {
      $$(".map-marker", root).forEach((item) => item.classList.remove("active")); marker.classList.add("active");
      const index = sites.findIndex((site) => site.id === Number(marker.dataset.siteId)); updateSitePanel(sites[index], index);
    }));
  }

  function selectCourse(id) {
    const course = courses.find((item) => item.id === id) || courses[0];
    if (!course) return;
    $("#courseMeta").textContent = `第 ${course.lesson} 课 · ${course.duration}`;
    $("#courseTitle").textContent = course.title; $("#courseDescription").textContent = course.description;
    $$("[data-course-id]").forEach((button) => button.classList.toggle("active", button.dataset.courseId === course.id));
    const player = $("#coursePlayer");
    player.dataset.videoUrl = course.videoUrl;
    if (course.posterUrl) player.style.backgroundImage = `url("${course.posterUrl}")`;
  }

  function renderCourses(items) {
    courses = items;
    $("#courseList").innerHTML = items.map((course) => `<button type="button" data-course-id="${course.id}"><span>0${course.lesson}</span><div><strong>${course.title}</strong><small>${course.duration} · 支教开源课程</small></div><i>→</i></button>`).join("");
    selectCourse(items[0]?.id);
  }

  function renderCreativeWorks(items) {
    $("#creativeGrid").innerHTML = items.map((item, index) => `<article class="creative-card creative-${index + 1}"><div class="creative-art"><span>${item.mark}</span><i>${String(index + 1).padStart(2, "0")}</i></div><div><small>${item.category}</small><h3>${item.name}</h3><p>${item.description}</p></div></article>`).join("");
  }

  async function init() {
    const [stats, mapConfig, sites, relics, courseItems, creativeItems] = await Promise.all([ApiService.getStats(), ApiService.getMapConfig(), ApiService.getSites(), ApiService.getRelics(), ApiService.getCourses(), ApiService.getCreativeWorks()]);
    $("#statRelics").textContent = stats.relics; $("#statSites").textContent = stats.sites; $("#statCourses").textContent = stats.courses;
    if (mapConfig.imageUrl) { const image = $("#mapSourceImage"); image.src = mapConfig.imageUrl; image.hidden = false; $("#shandongMap").classList.add("has-source-image"); }
    renderSites(sites); renderRelics(relics.items); renderCourses(courseItems); renderCreativeWorks(creativeItems);
    const aiStatus = await AiService.getStatus();
    const statusElement = $("#aiStatus");
    statusElement.classList.toggle("disconnected", !aiStatus.connected);
    statusElement.innerHTML = `<i></i> ${aiStatus.connected ? `百炼应用已连接 · ${escapeHtml(aiStatus.appId)}` : "百炼应用未连接 · 请启动本地服务"}`;
  }

  $("#menuToggle").addEventListener("click", () => { const open = $("#mainNav").classList.toggle("open"); $("#menuToggle").setAttribute("aria-expanded", String(open)); });
  $$("#mainNav a").forEach((link) => link.addEventListener("click", () => $("#mainNav").classList.remove("open")));
  $$(".filter-chip").forEach((button) => button.addEventListener("click", async () => { $$(".filter-chip").forEach((item) => item.classList.remove("active")); button.classList.add("active"); renderSites(await ApiService.getSites(button.dataset.period)); }));
  $$(".mode-control button").forEach((button) => button.addEventListener("click", () => { $$(".mode-control button").forEach((item) => item.classList.remove("active")); button.classList.add("active"); $("#digitalSeal").className = `digital-seal mode-${button.dataset.mode}`; $("#viewerMode").textContent = modeNames[button.dataset.mode]; }));

  $("#courseList").addEventListener("click", (event) => { const button = event.target.closest("[data-course-id]"); if (button) selectCourse(button.dataset.courseId); });
  $("#playCourse").addEventListener("click", () => { const url = $("#coursePlayer").dataset.videoUrl; if (url) window.open(url, "_blank", "noopener"); else showToast("课程视频接口已预留，替换 videoUrl 后即可播放"); });

  const searchDialog = $("#searchDialog");
  $("#openSearch").addEventListener("click", () => { searchDialog.showModal(); window.setTimeout(() => $("#searchInput").focus(), 50); });
  async function search() { const response = await ApiService.getRelics({ keyword: $("#searchInput").value }); $("#searchResults").innerHTML = response.items.length ? response.items.map((item) => `<button type="button" data-search-id="${item.id}"><strong>${item.name}</strong><span>${item.period} · ${item.location}</span></button>`).join("") : "<p>没有找到相关内容，请换个关键词。</p>"; }
  $("#doSearch").addEventListener("click", search); $("#searchInput").addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); search(); } });

  function appendMessage(text, role) { const message = document.createElement("div"); message.className = `chat-message ${role}`; message.textContent = text; $("#chatMessages").appendChild(message); $("#chatMessages").scrollTop = $("#chatMessages").scrollHeight; return message; }
  function clearSelectedImages() {
    selectedImages.forEach((item) => URL.revokeObjectURL(item.previewUrl));
    selectedImages = [];
    $("#aiImage").value = "";
    renderSelectedImages();
  }
  function renderSelectedImages() {
    const preview = $("#uploadPreview");
    preview.hidden = selectedImages.length === 0;
    $("#uploadCount").textContent = `已选择 ${selectedImages.length} 张图片`;
    $("#uploadThumbnails").innerHTML = selectedImages.map((item, index) => `<div class="upload-item"><img src="${item.previewUrl}" alt="待上传图片 ${index + 1}"><button type="button" data-remove-image="${item.id}" aria-label="移除${escapeHtml(item.file.name)}">×</button><span title="${escapeHtml(item.file.name)}">${escapeHtml(item.file.name)}</span></div>`).join("");
  }
  async function sendAiMessage(message) {
    const images = selectedImages.map((item) => item.file); if (!message && !images.length) return;
    const uploadText = images.length ? `已附带 ${images.length} 张图片` : "";
    appendMessage([message, uploadText].filter(Boolean).join(" · "), "user"); $("#aiQuestion").value = "";
    const pending = appendMessage("正在请求百炼智能体应用……", "assistant pending");
    const submitButton = $("#chatForm button[type='submit']"); submitButton.disabled = true;
    try {
      const result = await AiService.chat({ message, images, sessionId: aiSessionId });
      pending.textContent = result.reply; pending.classList.remove("pending"); clearSelectedImages();
      if (result.sessionId) { aiSessionId = result.sessionId; window.sessionStorage.setItem("nimeng-ai-session", aiSessionId); }
    } catch (error) { pending.textContent = error.message; pending.classList.remove("pending"); } finally { submitButton.disabled = false; }
  }
  $("#chatForm").addEventListener("submit", (event) => { event.preventDefault(); sendAiMessage($("#aiQuestion").value.trim()); });
  $$("[data-prompt]").forEach((button) => button.addEventListener("click", () => sendAiMessage(button.dataset.prompt)));
  $("#aiImage").addEventListener("change", () => {
    const files = [...$("#aiImage").files];
    const availableSlots = Math.max(0, 4 - selectedImages.length);
    const validFiles = files.filter((file) => {
      if (file.size > 5 * 1024 * 1024) { showToast(`${file.name} 超过 5MB，未加入上传队列`); return false; }
      return true;
    }).slice(0, availableSlots);
    if (files.length > availableSlots) showToast("一次最多选择 4 张图片");
    validFiles.forEach((file) => selectedImages.push({ id: `${Date.now()}-${Math.random()}`, file, previewUrl: URL.createObjectURL(file) }));
    $("#aiImage").value = ""; renderSelectedImages();
  });
  $("#uploadThumbnails").addEventListener("click", (event) => { const button = event.target.closest("[data-remove-image]"); if (!button) return; const index = selectedImages.findIndex((item) => item.id === button.dataset.removeImage); if (index >= 0) { URL.revokeObjectURL(selectedImages[index].previewUrl); selectedImages.splice(index, 1); renderSelectedImages(); } });
  $("#clearImages").addEventListener("click", clearSelectedImages);
  $("#clearChat").addEventListener("click", () => { $("#chatMessages").innerHTML = '<div class="chat-message assistant">对话已清空。还想向千问了解哪一枚封泥？</div>'; aiSessionId = ""; window.sessionStorage.removeItem("nimeng-ai-session"); clearSelectedImages(); });

  document.addEventListener("click", async (event) => {
    const notice = event.target.closest("[data-notice]"); if (notice) showToast(notice.dataset.notice);
    const detail = event.target.closest("[data-relic-id], [data-search-id]"); if (detail) { const relic = await ApiService.getRelicById(detail.dataset.relicId || detail.dataset.searchId); if (relic) showToast(`${relic.name}：${relic.inscription}，${relic.location}`); }
  });

  const navLinks = $$("#mainNav a");
  const observer = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) navLinks.forEach((link) => link.classList.toggle("active", link.getAttribute("href") === `#${entry.target.id}`)); }), { rootMargin: "-35% 0px -55%" });
  $$('main section[id]').forEach((section) => observer.observe(section));
  init().catch(() => showToast("页面数据加载失败，请刷新后重试"));
}());
