const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = Number(process.env.PORT || process.env.FC_SERVER_PORT || process.env.AI_SERVER_PORT || 3000);
const WEB_ROOT = __dirname;
const API_KEY = process.env.DASHSCOPE_API_KEY || "";
const APP_ID = process.env.DASHSCOPE_APP_ID || "c786fc9824414081980b6aa3258bb787";
const VISION_MODEL = process.env.QWEN_VL_MODEL || "qwen-vl-plus";
const DASHSCOPE_BASE_URL = process.env.DASHSCOPE_BASE_URL
  || "https://dashscope.aliyuncs.com/api/v1/apps";
const DASHSCOPE_COMPATIBLE_URL = process.env.DASHSCOPE_COMPATIBLE_URL
  || "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions";
const MAX_IMAGES = 4;
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_BODY_BYTES = 28 * 1024 * 1024;

function sendJson(response, status, data) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Disposition": "inline",
    "X-Content-Type-Options": "nosniff",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
  });
  response.end(JSON.stringify(data));
}

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml"
};

function serveStatic(request, response) {
  const requestPath = decodeURIComponent(new URL(request.url, "http://127.0.0.1").pathname);
  const relativePath = requestPath === "/" ? "index.html" : requestPath.replace(/^\/+/, "");
  const filePath = path.resolve(WEB_ROOT, relativePath);
  if (!filePath.startsWith(`${WEB_ROOT}${path.sep}`)) return sendJson(response, 403, { error: "禁止访问" });

  fs.stat(filePath, (statError, stat) => {
    if (statError || !stat.isFile()) return sendJson(response, 404, { error: "文件不存在" });
    response.writeHead(200, {
      "Content-Type": MIME_TYPES[path.extname(filePath).toLowerCase()] || "application/octet-stream",
      "Content-Disposition": "inline",
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "no-cache"
    });
    fs.createReadStream(filePath).pipe(response);
  });
}

function readJson(request) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    request.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new Error("请求内容过大"));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on("end", () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8"))); }
      catch { reject(new Error("请求数据格式不正确")); }
    });
    request.on("error", reject);
  });
}

function validateImages(images) {
  if (!Array.isArray(images)) throw new Error("images 必须是数组");
  if (images.length > MAX_IMAGES) throw new Error(`一次最多上传 ${MAX_IMAGES} 张图片`);
  images.forEach((image) => {
    if (!image.type?.startsWith("image/")) throw new Error(`${image.name || "文件"} 不是图片`);
    if (Number(image.size) > MAX_IMAGE_BYTES) throw new Error(`${image.name || "图片"} 超过 5MB`);
    if (!String(image.dataUrl || "").startsWith("data:image/")) throw new Error("图片数据格式不正确");
  });
}

async function askBailianApplication({ message, sessionId, images }) {
  const input = { prompt: message };
  if (sessionId && sessionId !== "web-guest") input.session_id = sessionId;

  const upstream = await fetch(`${DASHSCOPE_BASE_URL}/${encodeURIComponent(APP_ID)}/completion`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      input,
      parameters: {},
      debug: {}
    })
  });
  const data = await upstream.json().catch(() => ({}));
  if (!upstream.ok) {
    const reason = data.error?.message || data.message || `上游接口返回 ${upstream.status}`;
    throw new Error(reason);
  }
  return {
    reply: data.output?.text || "百炼应用没有返回文本内容",
    sessionId: data.output?.session_id || sessionId,
    requestId: data.request_id || null,
    usage: data.usage || null,
    appId: APP_ID
  };
}

async function askQwenVision({ message, images }) {
  const content = [
    ...images.map((image) => ({ type: "image_url", image_url: { url: image.dataUrl } })),
    {
      type: "text",
      text: message || "请观察上传的封泥图片，描述可见形态、印面、文字线条和保存状态，并谨慎给出可能的印文候选。"
    }
  ];

  const upstream = await fetch(DASHSCOPE_COMPATIBLE_URL, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: VISION_MODEL,
      messages: [
        {
          role: "system",
          content: "你是‘丁见泥’，齐鲁封泥数字文化平台的AI导览助手。分析图片时先描述可见事实，再给出候选释读和判断依据。不得把模糊、残缺或有争议的古文字识别写成定论，不得编造文物出处、年代和收藏信息。结尾提醒用户正式释读需要文博或古文字专家复核。"
        },
        { role: "user", content }
      ],
      temperature: 0.2
    })
  });

  const data = await upstream.json().catch(() => ({}));
  if (!upstream.ok) {
    const reason = data.error?.message || data.message || `视觉模型返回 ${upstream.status}`;
    throw new Error(reason);
  }
  return {
    reply: data.choices?.[0]?.message?.content || "千问视觉模型没有返回文本内容",
    model: data.model || VISION_MODEL,
    usage: data.usage || null,
    mode: "vision"
  };
}

const server = http.createServer(async (request, response) => {
  if (request.method === "OPTIONS") return sendJson(response, 204, {});

  if (request.method === "GET" && request.url === "/api/ai/status") {
    return sendJson(response, 200, {
      connected: Boolean(API_KEY && APP_ID),
      provider: "Bailian Application",
      appId: APP_ID ? `${APP_ID.slice(0, 6)}...` : "",
      supportsImages: true,
      visionModel: VISION_MODEL
    });
  }

  if (request.method === "POST" && request.url === "/api/ai/chat") {
    if (!API_KEY) return sendJson(response, 503, { error: "尚未设置 DASHSCOPE_API_KEY" });
    if (!APP_ID) return sendJson(response, 503, { error: "尚未设置 DASHSCOPE_APP_ID" });
    try {
      const body = await readJson(request);
      const message = String(body.message || "").trim();
      const images = body.images || [];
      validateImages(images);
      if (!message && images.length === 0) return sendJson(response, 400, { error: "请输入问题或上传图片" });
      const result = images.length
        ? await askQwenVision({ message, images })
        : await askBailianApplication({ message, sessionId: body.sessionId, images });
      return sendJson(response, 200, result);
    } catch (error) {
      return sendJson(response, 400, { error: error.message || "请求处理失败" });
    }
  }

  if (request.method === "GET") return serveStatic(request, response);
  return sendJson(response, 404, { error: "接口不存在" });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Website and Qwen proxy listening on 0.0.0.0:${PORT}`);
  console.log(`Bailian application: ${APP_ID || "missing"}`);
  console.log(`Vision model: ${VISION_MODEL}`);
  console.log(API_KEY ? "DASHSCOPE_API_KEY is configured" : "DASHSCOPE_API_KEY is missing");
});
