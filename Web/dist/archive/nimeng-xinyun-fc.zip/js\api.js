(function () {
  const delay = (value, ms = 120) => new Promise((resolve) => setTimeout(() => resolve(value), ms));

  // 页面只通过此服务读取业务数据。接入后端时，在此处替换为 fetch 请求。
  window.ApiService = {
    async getStats() { return delay({ ...window.MOCK_DATA.stats }); },
    async getMapConfig() { return delay({ imageUrl: window.MOCK_DATA.mapImageUrl }); },
    async getSites(period = "全部") {
      const items = period === "全部" ? window.MOCK_DATA.sites : window.MOCK_DATA.sites.filter((site) => site.tags.includes(period));
      return delay(items.map((item) => ({ ...item })));
    },
    async getRelics(params = {}) {
      const keyword = String(params.keyword || "").trim().toLowerCase();
      const items = window.MOCK_DATA.relics.filter((item) => !keyword || [item.name, item.inscription, item.period, item.location, item.category, item.value].some((field) => field.toLowerCase().includes(keyword)));
      return delay({ items: items.map((item) => ({ ...item })), total: items.length });
    },
    async getRelicById(id) { return delay(window.MOCK_DATA.relics.find((item) => item.id === id) || null); },
    async getCourses() { return delay(window.MOCK_DATA.courses.map((item) => ({ ...item }))); },
    async getCreativeWorks() { return delay(window.MOCK_DATA.creativeWorks.map((item) => ({ ...item }))); }
  };
}());
