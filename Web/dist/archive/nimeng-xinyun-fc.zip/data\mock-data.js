window.MOCK_DATA = {
  stats: { relics: 86, sites: 12, courses: 8 },
  mapImageUrl: "",
  sites: [
    { id: 1, city: "淄博 · 临淄", name: "齐故城封泥调研点", period: "战国至汉代", tags: ["战国", "汉代"], count: 18, x: 53, y: 48, description: "临淄是齐文化的重要中心。相关封泥为研究官署体系、行政往来和齐地古文字提供了直接证据。" },
    { id: 2, city: "济南 · 章丘", name: "章丘封泥资料调研点", period: "秦汉时期", tags: ["秦代", "汉代"], count: 11, x: 40, y: 39, description: "章丘地处齐鲁交通要冲，调研资料帮助观察文书流转、物资管理与区域治理之间的联系。" },
    { id: 3, city: "临沂 · 兰山", name: "沂蒙汉代遗存调研点", period: "西汉至东汉", tags: ["汉代"], count: 9, x: 50, y: 70, description: "临沂汉代遗存丰富，封泥与简牍资料可相互参照，呈现基层行政活动的真实片段。" },
    { id: 4, city: "青岛 · 即墨", name: "即墨故城周边调研点", period: "战国至秦代", tags: ["战国", "秦代"], count: 7, x: 72, y: 48, description: "古即墨曾是齐国重要城邑，封泥资料有助于理解区域权力与沿海交通的关系。" }
  ],
  relics: [
    { id: "NMX-001", name: "齐郡之印封泥", inscription: "齐郡之印", period: "汉代", location: "山东临淄", category: "官署封泥", tone: "clay", value: "制度价值", summary: "印面方正，四字布局紧凑。其官署称谓可与史籍互证，用于研究汉代齐郡的行政建置与文书制度。" },
    { id: "NMX-002", name: "即墨官印封泥", inscription: "即墨之印", period: "战国", location: "山东即墨", category: "地域封泥", tone: "ink", value: "地域价值", summary: "印文保存了古即墨的地域信息，为观察齐国东部城邑治理、地名沿革与交通联系提供实物参照。" },
    { id: "NMX-003", name: "仓府封泥", inscription: "仓府", period: "秦代", location: "山东章丘", category: "仓储封泥", tone: "bronze", value: "经济价值", summary: "印文与仓储机构相关，反映古代物资出入、仓库管理和凭证核验，是理解社会运行的微观材料。" },
    { id: "NMX-004", name: "琅邪尉印封泥", inscription: "琅邪尉印", period: "汉代", location: "山东临沂", category: "职官封泥", tone: "sand", value: "文字价值", summary: "职官名称与印文字形清晰，可用于研究汉代地方行政层级、官印制度以及篆书字形演变。" }
  ],
  courses: [
    { id: "COURSE-01", title: "一块泥，如何守住一封信？", lesson: 1, duration: "12 分钟", description: "从生活中的防拆封条出发，认识古代封泥的制作方式和实际用途。", videoUrl: "", posterUrl: "" },
    { id: "COURSE-02", title: "跟着封泥认识齐鲁古城", lesson: 2, duration: "15 分钟", description: "把文物信息放回地图，理解临淄、即墨与琅邪等历史地点。", videoUrl: "", posterUrl: "" },
    { id: "COURSE-03", title: "小小古文字观察员", lesson: 3, duration: "18 分钟", description: "从线条、结构和印面方向入手，尝试辨认封泥上的古文字。", videoUrl: "", posterUrl: "" }
  ],
  creativeWorks: [
    { id: "CREATIVE-01", name: "丁见泥 IP 形象", category: "角色设计", mark: "丁", description: "以封泥轮廓和印文为视觉线索，让专业内容有一位亲切的讲述者。" },
    { id: "CREATIVE-02", name: "封泥纹样明信片", category: "纸品设计", mark: "印", description: "将典型印文转化为可阅读、可收藏的日常图形。" },
    { id: "CREATIVE-03", name: "模拟封缄课程教具", category: "教育文创", mark: "封", description: "在支教课堂中动手体验系绳、覆泥和钤印的完整过程。" }
  ]
};
