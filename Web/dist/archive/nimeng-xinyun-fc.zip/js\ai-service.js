(function () {
  const API_URL = "/api/ai/chat";

  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve({
        name: file.name,
        type: file.type,
        size: file.size,
        dataUrl: reader.result
      });
      reader.onerror = () => reject(new Error(`无法读取图片：${file.name}`));
      reader.readAsDataURL(file);
    });
  }

  window.AiService = {
    async getStatus() {
      try {
        const response = await fetch("/api/ai/status");
        if (!response.ok) return { connected: false, appId: "" };
        return response.json();
      } catch {
        return { connected: false, appId: "" };
      }
    },

    async chat({ message, images = [], sessionId = "guest" }) {
      const encodedImages = await Promise.all(images.map(fileToDataUrl));
      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, sessionId, images: encodedImages })
      });

      const result = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(result.error || "千问服务暂时不可用，请确认本地AI服务已经启动");
      }
      return result;
    }
  };
}());
